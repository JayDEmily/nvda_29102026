NVDA Python 3.13.5 offline wheelhouse — complete 16 wheels

Target: Linux x86_64 glibc, CPython 3.13.5.
All 16 SHA256 hashes match the manifest.

Verifying wheel bytes:
  cd NVDA_PY313_OFFLINE_WHEELHOUSE_20261023 && sha256sum -c SHA256SUMS

Offline installation into a clean venv:
  python3.13 -m venv .venv
  .venv/bin/python -m pip install --no-index --find-links wheelhouse 'mypy==1.20.1' 'librt==0.16.0' 'PyYAML==6.0.3' 'pytest==9.0.3' 'ruff==0.15.11'
  .venv/bin/python -m mypy --version
  .venv/bin/python -m pip check

The package set was assembled for the approved CPython 3.13.5 exception.
It does not amend the original NVDA CPython 3.12.14 lock or imply D016 acceptance.

Acquisition provenance: private GitHub Actions workflow on isolated branch
  repository: JayDEmily/rowing2026-python-environment
  branch: work/nvda-py313-wheel-acquisition-20261023
  run: 39885328182; artifact: 12471683487
  source commit: e80863f592882cba650e9293932e200c4690eaa5

The GitHub workflow verified exact PyPI SHA256 digests for the three cp313 wheels.
