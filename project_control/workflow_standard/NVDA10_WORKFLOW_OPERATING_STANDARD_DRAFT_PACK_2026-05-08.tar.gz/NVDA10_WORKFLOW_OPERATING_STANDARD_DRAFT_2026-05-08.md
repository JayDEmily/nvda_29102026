# NVDA10 Workflow Operating Standard — Draft

**Status:** Draft for user review  
**Date:** 2026-05-08  
**Project:** NVDA10 / NVDA9 bridge, Atlas migration, native codebase, audit and repair workflow  
**Purpose:** Define the repeatable working method for using GPT reasoning, ChatGPT sandbox, Git, TAR capsules, GitHub, Codex, and local Ubuntu without losing work or reopening old archaeology unnecessarily.

---

## 0. How future threads must use this document

This document is a **workflow standard**, not a task plan and not a project evidence bundle.

A future GPT thread should use it in two passes:

1. **Index pass:** read the table of contents and Section 2 to decide which sections are in scope.
2. **Full-read pass:** once a section is in scope, read that section in full before relying on it.

This document deliberately avoids requiring every future thread to read every section for every task. That would waste context and increase drift. The rule is:

> Do not skim files or sections that are in scope. Use the routing table to decide scope first. Once something is in scope, read it in full before relying on it.

---

## 1. Table of contents

1. Table of contents
2. Scope routing table
3. Authority hierarchy
4. Environment roles
5. Sandbox stability rules
6. Git memory protocol
7. TAR checkpoint protocol
8. VENV policy
9. Testing and validation policy
10. Missing information policy
11. Artefact packaging policy
12. GitHub, Codex, and local-machine workflow
13. Evidence and proof standards
14. Standard task launch checklist
15. Standard closeout checklist
16. Forbidden anti-patterns
17. Standard worker brief clauses
18. Open items and caveats
19. Official-document alignment notes

---

## 2. Scope routing table

Use this table before reading the whole document.

| Task type | Sections in scope by default | Notes |
|---|---:|---|
| New sandbox repo/code task | 3, 4, 5, 6, 7, 9, 13, 14, 15, 16 | Read task-specific `AGENTS.md`, `PLANS.md`, `EXEC_PLAN.md` separately if present. |
| Long-running audit/consolidation task | 3, 4, 5, 6, 7, 10, 11, 13, 14, 15, 16 | Use Git and checkpointing from the start. |
| VENV/environment task | 4, 5, 6, 7, 8, 13, 14, 15, 16 | Keep VENV gates separate from code repair gates. |
| Test/validation task | 4, 5, 6, 7, 9, 13, 15, 16 | Use targeted tests before broad batches. |
| Packaging/handoff task | 5, 6, 7, 10, 11, 13, 15, 16 | Produce hashes, manifests, and forbidden-payload scans. |
| GitHub/Codex bridge task | 4, 6, 7, 11, 12, 13, 14, 15, 16 | GitHub is for source/diff sync; TARs are for large payload transfer. |
| PM/control task | 2, 3, 10, 11, 13, 14, 15, 16 | Do not mutate code unless explicitly authorised. |
| Historical archaeology task | 2, 3, 10, 11, 13, 16 | Do not let archaeology restart current work unless the current task asks for it. |

---

## 3. Authority hierarchy

Use this hierarchy unless the user gives a stronger instruction in the current conversation:

1. Current user instruction.
2. Active task `EXEC_PLAN.md`, if present and accepted.
3. This workflow operating standard.
4. Repo-local authority files, such as `AGENTS.md`, `PLANS.md`, route overrides, and normative docs.
5. Accepted handoff/index packs.
6. Historical artefacts.
7. Inference from filenames, summaries, or memory.

Rules:

- If a current user instruction conflicts with older workflow material, stop and surface the conflict.
- If a file is in scope, read it in full before relying on it.
- Do not use old artefacts to override a newer accepted source-of-truth pack.
- Do not claim work is complete, verified, accepted, or closed unless the evidence is present.

---

## 4. Environment roles

The project uses several environments. They should not be treated as interchangeable.

| Environment | Primary role | Do not use it as |
|---|---|---|
| GPT reasoning thread | Architecture, planning, repair design, evidence interpretation, worker briefs | The only durable state store |
| ChatGPT sandbox | Short repair work, archive inspection, patch creation, targeted proof runs, TAR packaging | Long-term workspace or full validation bench |
| Git | Memory, rollback, branch state, proof of change | A substitute for proof logs |
| TAR.GZ capsule | Transfer unit for full work state or evidence packs | A place to hide caches, VENV, or random nested junk |
| GitHub | Source/diff synchronisation, branch/PR handoff | Blob-transfer backbone for large TAR/ZIP files through the GPT connector |
| Codex / Codex Cloud | Durable repo checkout, setup scripts, long validation, PR workflow | A replacement for high-context PM judgement |
| Local Ubuntu / VS Code | Durable authority bench for full VENV, long tests, GitHub push/pull | A reason to skip sandbox proof when sandbox proof is explicitly requested |

Practical rule:

> GPT does the thinking; Git remembers; TAR moves the body; Codex/local machine does durable bench work; the sandbox is disposable machinery.

---

## 5. Sandbox stability rules

The ChatGPT sandbox must be treated as volatile.

Required rules for serious work:

1. Initialise Git before meaningful work.
2. Commit a baseline before mutation.
3. Commit after each meaningful repair or consolidation block.
4. Create a checkpoint TAR before broad validation, VENV creation, large archive extraction, or final packaging.
5. Use `/tmp` for noisy execution, extracted scratch trees, and test logs.
6. Use `/mnt/data` for final downloadable artefacts only.
7. Do not rely on a single final download link as the only copy of meaningful work.
8. If a command times out, inspect logs and rerun the smallest meaningful unit.
9. Treat timeouts as inconclusive until logs show a real assertion failure or pass.
10. Remove generated caches before packaging.

The sandbox is useful. It is not trusted as the only durable workspace.

---

## 6. Git memory protocol

For any serious sandbox worktree, initialise Git immediately unless an existing valid `.git/` is present.

Minimum sequence:

```bash
git init
git add -A
git commit -m "baseline: accepted input state"
git checkout -b work/<task-name>
```

Commit after:

- authority/intake setup;
- source/test repair block;
- successful targeted validation;
- meaningful documentation/control update;
- before risky broad validation;
- before packaging.

Every checkpoint TAR should preserve either:

- `.git/` and the worktree; or
- a patch plus enough source state to apply it deterministically.

Do not leave valuable work only as uncommitted files in the sandbox.

---

## 7. TAR checkpoint protocol

Use `.tar.gz` as the default transfer capsule.

A good checkpoint TAR contains:

```text
repo_root/
  .git/                  # if this is a Git-backed worktree checkpoint
  working tree
artefacts/
  patch
  changed-files ledger
  proof logs
  git status/log/head
MANIFEST.sha256
```

Default exclusions:

```text
.venv/
__pycache__/
.pytest_cache/
*.pyc
wheelhouses unless explicitly required
large unrelated input archives
nested TAR/ZIP payloads unless intentionally carried as raw evidence
```

Before final packaging:

```bash
find . -type d -name '__pycache__' -prune -exec rm -rf {} +
find . -type d -name '.pytest_cache' -prune -exec rm -rf {} +
find . -type f -name '*.pyc' -delete
```

Every package must include:

- manifest;
- byte size;
- SHA256;
- forbidden-payload scan;
- short index explaining purpose and role.

---

## 8. VENV policy

Do not create a VENV unless the current task explicitly opens a VENV/environment gate.

Reason:

- VENV creation generates many files.
- It can consume sandbox disk quickly.
- It increases cache and package churn.
- It makes checkpoint TARs easy to contaminate.

If a VENV task is authorised:

1. checkpoint before VENV creation;
2. create the VENV as an isolated gate;
3. record exact commands and package source;
4. do not combine VENV creation with unrelated code repair;
5. never include `.venv/` in final handoff unless explicitly required by the user.

Minimum acceptable VENV proof:

- command log;
- package/install log;
- import smoke result;
- `pip check` or equivalent if available;
- no-source-mutation proof after cleanup.

---

## 9. Testing and validation policy

Default order:

1. compile check;
2. targeted tests for the active repair/scope;
3. broader validation in small batches;
4. rerun failed batches after repair;
5. final proof summary.

Do not run broad pytest as one giant sandbox command unless specifically authorised.

Preferred broad-test pattern:

```bash
find tests -name 'test_*.py' | sort > /tmp/test_files.txt
```

Run in small batches, usually three test files per batch.

Each batch must record:

- batch number;
- file list;
- stdout;
- stderr;
- exit status;
- summary.

If a batch fails:

- inspect the failure;
- determine whether it is caused by the active repair or is unrelated/pre-existing;
- fix active-scope defects;
- rerun the smallest failing unit;
- continue once resolved.

A timeout is not a failure by itself. It is `UNKNOWN` until a smaller rerun proves pass or failure.

---

## 10. Missing information policy

Do not stop the whole task just because one item is unavailable.

Required behaviour:

1. Search obvious locations first.
2. Search nested archives when relevant.
3. Record exact filenames, expected hashes, and search locations.
4. Classify missing items by operational impact:
   - blocker;
   - high provenance caveat;
   - low provenance caveat;
   - historical only.
5. Continue all other authorised work.

Use this language:

```text
FOUND
EQUIVALENT_FOUND
NOT_FOUND_EXACT
NOT_CONFIRMED
MISSING_BLOCKER
MISSING_NON_BLOCKING_CAVEAT
```

Do not write “unavailable” until nested archive search has been attempted or explicitly ruled out by scope/resource constraints.

---

## 11. Artefact packaging policy

Package by role, not by panic.

Use small, labelled capsules instead of one giant archive.

Recommended roles:

1. current active codebase/docs/tests/audit;
2. bridge/control workspace;
3. six-gap audit/repair history;
4. Atlas/donor/bridge-source material;
5. historical source snapshots;
6. master index / workflow-chain map;
7. later supplements/search findings.

Each package must answer:

- What is this?
- Where does it sit in the workflow chain?
- Is it current, support, historical, or search-proof?
- What should future work use it for?
- What must future work not use it for?

Do not duplicate large payloads in the master index. The master index should bind packages together by lock, role, and workflow position.

---

## 12. GitHub, Codex, and local-machine workflow

GitHub should carry source/diffs/branches, not serve as the main blob shuttle through the GPT connector.

Codex/local-machine work should use a normal repo root containing:

```text
AGENTS.md
PLANS.md
pyproject.toml
src/
tests/
docs/
config/
```

Do not ask Codex to infer the project from a wrapper folder full of proof logs or nested archives.

Recommended flow:

1. GPT sandbox creates or refines patch/control artefact.
2. Sandbox commits work and packages a TAR checkpoint.
3. User extracts locally if needed.
4. User pushes normal repo branch to GitHub.
5. Codex/local machine runs durable VENV/full validation.
6. GPT reasoning thread interprets results and decides next gate.

---

## 13. Evidence and proof standards

Do not claim work was read, fixed, implemented, passed, verified, accepted, or closed unless the proof exists.

Acceptable proof includes:

- file path and line ranges;
- command output and exit status;
- SHA256 and byte size;
- manifest verification;
- git diff or patch;
- git status/log/head;
- test logs and status files;
- full-read ledger;
- package inventory;
- official documentation citation where external/current claims matter.

If proof is absent, say:

```text
Unknown
Inferred
Not inspected
Not verified
```

---

## 14. Standard task launch checklist

Before mutating files:

1. Restate objective in one sentence.
2. Identify task mode:
   - code repair;
   - audit/consolidation;
   - VENV/environment;
   - packaging;
   - PM/control;
   - validation.
3. Identify source-of-truth files/packages.
4. Identify in-scope sections/docs/files.
5. Read in-scope material in full.
6. Initialise or confirm Git.
7. Commit baseline before mutation.
8. State first gate and pass/fail criteria.
9. Start work.

Do not restart planning if a valid active `EXEC_PLAN.md` or accepted gate plan already exists.

---

## 15. Standard closeout checklist

A closeout must include:

- what was actually done;
- what was actually inspected/read;
- files changed;
- tests/commands run;
- command exit statuses;
- proof logs;
- git status;
- patch/diff if source changed;
- package link if an artefact was created;
- known remaining caveats;
- next gate.

After each gate, summarise:

```text
Known true
Ruled out
Next gate
```

For long-running tasks, do not stop merely because a gate passed. Continue into the next authorised gate until blocked, completed, or approaching context/resource limits.

---

## 16. Forbidden anti-patterns

Do not:

- leave meaningful work only in the sandbox;
- run broad tests as one giant command when batching is safer;
- create VENVs in mixed repair gates without explicit authority;
- package `.venv`, caches, bytecode, or random nested archives;
- treat filename similarity as proof;
- treat a timeout as a test failure without rerun evidence;
- ask a future worker to do what the current thread can do now;
- restart archaeology when a current accepted index exists;
- confuse the active codebase with bridge/control material;
- confuse historical snapshots with current source;
- claim direct evidence exists when only replacement disposition exists;
- use GitHub blob transfer as the primary large-artifact movement path through GPT.

---

## 17. Standard worker brief clauses

Use this block for sandbox-heavy worker tasks:

```text
Sandbox stability rules:

1. Initialise Git before work unless a valid Git worktree already exists.
2. Commit baseline before mutation.
3. Commit after each meaningful repair block.
4. Create a checkpoint TAR before broad validation.
5. Run pytest in isolated batches, not one broad command.
6. Do not create a VENV unless this is explicitly a VENV gate.
7. Use /tmp for noisy validation and /mnt/data only for final artefacts.
8. Remove __pycache__, *.pyc, and .pytest_cache before packaging.
9. If a command times out, inspect logs and rerun the smallest failing unit.
10. Never rely on the sandbox as the only copy of meaningful work.
```

Use this block for missing evidence:

```text
If an expected artefact is missing, search nested archives before declaring it unavailable. If still missing, log exact search locations, mark operational impact, and continue all other authorised work.
```

---

## 18. Open items and caveats

This draft is project-specific and based on observed NVDA10 workflow behaviour.

Known caveats:

- Exact ChatGPT UI sandbox CPU/RAM/disk/process limits are not formally specified in the project evidence.
- Some sandbox failure patterns are observed behaviour, not official platform guarantees.
- This document should be reviewed after several future work passes and promoted from draft to frozen only if it remains useful.

Promotion recommendation:

1. User reviews this draft.
2. Amend wording if needed.
3. Create frozen version with immutable filename.
4. Add it to the master project universe index.
5. Future ExecPlans should reference it as workflow law.

---

## 19. Official-document alignment notes

This workflow standard is aligned with these official OpenAI-documented constraints and surfaces:

- ChatGPT data analysis can inspect uploaded files and run code-backed analysis, but its Python environment cannot make external web requests or API calls.
- ChatGPT file uploads have file-size, token, rate, and storage constraints; upload success does not guarantee that a large or complex file can be fully analysed in one pass.
- Codex is intended for repository-oriented coding workflows, including controlled changes, validation loops, and codebase understanding tasks.

This document also includes project-specific operational rules that are based on observed NVDA10 experience, not official OpenAI guarantees. Those rules are labelled by behaviour rather than claimed as platform documentation.
