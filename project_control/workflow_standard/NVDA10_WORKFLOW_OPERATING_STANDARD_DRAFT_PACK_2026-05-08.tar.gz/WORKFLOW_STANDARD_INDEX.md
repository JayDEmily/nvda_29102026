# NVDA10 Workflow Standard Index

Open first:

1. `NVDA10_WORKFLOW_OPERATING_STANDARD_DRAFT_2026-05-08.md`
2. Section 2, `Scope routing table`
3. Then read only the sections that Section 2 puts in scope for the task.

Core rule:

> Do not skim material that is in scope. Use the index to determine scope first. Once in scope, read in full before relying on it.

