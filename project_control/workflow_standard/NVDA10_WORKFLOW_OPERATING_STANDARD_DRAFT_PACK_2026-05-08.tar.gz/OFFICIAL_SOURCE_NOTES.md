# Official source notes used for this draft

These notes are for review only. The workflow document avoids over-claiming exact sandbox resource limits.

- OpenAI Help Center: Data analysis with ChatGPT — uploaded file analysis and Python environment constraints.
- OpenAI Help Center: File Uploads FAQ — upload size/token/rate/storage constraints and retention notes.
- OpenAI Developers: Codex use cases — repository-oriented codebase work, code review, migrations, and understanding large codebases.

Project-specific stability rules are based on observed NVDA10 behaviour and should not be treated as official OpenAI platform guarantees.
